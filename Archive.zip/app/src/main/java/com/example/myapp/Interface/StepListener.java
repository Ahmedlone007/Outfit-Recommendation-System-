package com.example.myapp.Interface;

public interface StepListener {
    void onStepComplete(String data);
}
